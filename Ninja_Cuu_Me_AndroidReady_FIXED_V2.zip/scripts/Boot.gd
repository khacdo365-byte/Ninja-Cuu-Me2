extends Node2D

func _ready() -> void:
    queue_redraw()
    call_deferred("_open_menu")

func _open_menu() -> void:
    if is_inside_tree():
        get_tree().change_scene_to_file("res://scenes/MainMenu.tscn")

func _draw() -> void:
    draw_rect(Rect2(0, 0, 720, 1280), Color("#07101f"))
    draw_string(
        ThemeDB.fallback_font,
        Vector2(0, 620),
        "NINJA CỨU MẸ",
        HORIZONTAL_ALIGNMENT_CENTER,
        720,
        44,
        Color("#f5d76e")
    )
    draw_string(
        ThemeDB.fallback_font,
        Vector2(0, 680),
        "Đang khởi động...",
        HORIZONTAL_ALIGNMENT_CENTER,
        720,
        24,
        Color.WHITE
    )
