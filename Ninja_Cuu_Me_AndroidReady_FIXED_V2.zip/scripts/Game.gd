extends Node
var level := 1
var coins := 0
var max_hp := 5
var attack_level := 1
var speed_level := 1
var rescued := false
var save_path := "user://ninja_save.json"

func _ready():
    load_save()

func _change_scene(path: String) -> void:
    if ResourceLoader.exists(path):
        get_tree().change_scene_to_file(path)

func new_game():
    level = 1
    coins = 0
    max_hp = 5
    attack_level = 1
    speed_level = 1
    rescued = false
    save_game()
    goto_level()

func goto_menu():
    call_deferred("_change_scene", "res://scenes/MainMenu.tscn")

func goto_level():
    call_deferred("_change_scene", "res://scenes/Level.tscn")

func complete_level():
    level += 1
    coins += 100
    save_game()
    if level > 3:
        rescued = true
        goto_ending()
    else:
        goto_level()

func goto_ending():
    call_deferred("_change_scene", "res://scenes/Ending.tscn")

func buy_attack():
    var cost = 150 * attack_level
    if coins >= cost:
        coins -= cost
        attack_level += 1
        save_game()
        return true
    return false

func buy_speed():
    var cost = 150 * speed_level
    if coins >= cost:
        coins -= cost
        speed_level += 1
        save_game()
        return true
    return false

func save_game():
    var data = {"level":level,"coins":coins,"max_hp":max_hp,"attack_level":attack_level,"speed_level":speed_level,"rescued":rescued}
    var f = FileAccess.open(save_path, FileAccess.WRITE)
    f.store_string(JSON.stringify(data))

func load_save():
    if not FileAccess.file_exists(save_path): return
    var f = FileAccess.open(save_path, FileAccess.READ)
    var d = JSON.parse_string(f.get_as_text())
    if typeof(d) == TYPE_DICTIONARY:
        level=int(d.get("level",1))
        coins=int(d.get("coins",0))
        max_hp=int(d.get("max_hp",5))
        attack_level=int(d.get("attack_level",1))
        speed_level=int(d.get("speed_level",1))
        rescued=bool(d.get("rescued",false))
