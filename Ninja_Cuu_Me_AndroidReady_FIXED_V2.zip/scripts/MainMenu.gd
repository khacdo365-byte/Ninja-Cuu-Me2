extends Node2D

const VIEW_W := 720.0
const VIEW_H := 1280.0
const PLAY_RECT := Rect2(110, 770, 500, 120)

var ninja_tex: Texture2D = preload("res://assets/ninja_be.png")

func _ready() -> void:
    queue_redraw()

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed:
        if event.keycode == KEY_ENTER or event.keycode == KEY_SPACE:
            Game.new_game()
            get_viewport().set_input_as_handled()
    elif event is InputEventMouseButton and event.pressed:
        if PLAY_RECT.has_point(event.position):
            Game.new_game()
            get_viewport().set_input_as_handled()
    elif event is InputEventScreenTouch and event.pressed:
        if PLAY_RECT.has_point(event.position):
            Game.new_game()
            get_viewport().set_input_as_handled()

func _draw() -> void:
    draw_rect(Rect2(0, 0, VIEW_W, VIEW_H), Color("#07101f"))

    # Moon and background clouds.
    draw_circle(Vector2(560, 150), 85.0, Color("#f2d98c"))
    for x in [80.0, 250.0, 440.0, 620.0]:
        draw_circle(Vector2(x, 340), 48.0, Color("#122945"))
        draw_circle(Vector2(x + 42.0, 335), 58.0, Color("#122945"))

    # Character.
    if is_instance_valid(ninja_tex):
        var tex_h := 300.0
        var ratio := float(ninja_tex.get_width()) / float(ninja_tex.get_height())
        draw_texture_rect(
            ninja_tex,
            Rect2(285, 300, tex_h * ratio, tex_h),
            false
        )

    var font := ThemeDB.fallback_font

    draw_string(font, Vector2(0, 90), "NINJA CỨU MẸ",
        HORIZONTAL_ALIGNMENT_CENTER, VIEW_W, 52, Color("#f5d76e"))

    draw_string(font, Vector2(55, 675), "BÉ NINJA - HÀNH TRÌNH GIẢI CỨU MẸ",
        HORIZONTAL_ALIGNMENT_CENTER, 610, 25, Color("#d9e7ff"))

    draw_rect(PLAY_RECT, Color("#b32636"))
    draw_string(font, Vector2(0, 848), "CHƠI GAME",
        HORIZONTAL_ALIGNMENT_CENTER, VIEW_W, 38, Color.WHITE)

    draw_string(font, Vector2(0, 970), "Màn hình dọc - Điều khiển cảm ứng",
        HORIZONTAL_ALIGNMENT_CENTER, VIEW_W, 24, Color("#a8bad4"))
    draw_string(font, Vector2(0, 1015), "Trái / Phải  -  Nhảy  -  Tấn công",
        HORIZONTAL_ALIGNMENT_CENTER, VIEW_W, 22, Color("#8fa8c9"))
    draw_string(font, Vector2(0, 1190), "Bản V2 - Bé Ninja",
        HORIZONTAL_ALIGNMENT_CENTER, VIEW_W, 18, Color("#60799b"))
