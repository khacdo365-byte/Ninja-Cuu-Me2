extends Node2D

const W = 720.0
const H = 1280.0
const GROUND_Y = 1130.0
const GRAVITY = 1850.0

var player = Vector2(115, 1035)
var vel = Vector2.ZERO
var facing = 1.0
var hp = 5
var attack_t = 0.0
var attack_cd = 0.0
var invuln = 0.0
var msg_t = 0.0
var msg = ""
var won = false
var boss_hp = 0
var boss_pos = Vector2(560, 360)
var enemies = []
var coins = []
var platforms = []
var ninja_tex = preload("res://assets/ninja_be.png")

func _ready():
    hp = Game.max_hp
    build_level()
    queue_redraw()

func build_level():
    platforms = [Rect2(0, GROUND_Y, W, 150)]
    if Game.level == 1:
        platforms += [
            Rect2(80, 930, 220, 28), Rect2(410, 820, 220, 28),
            Rect2(120, 690, 210, 28), Rect2(430, 560, 210, 28),
            Rect2(90, 420, 200, 28), Rect2(390, 290, 240, 28)]
        enemies = [{"p":Vector2(560,1020),"hp":2},{"p":Vector2(180,880),"hp":2},{"p":Vector2(520,770),"hp":3},{"p":Vector2(180,640),"hp":3}]
        coins = [Vector2(180,885),Vector2(520,775),Vector2(220,645),Vector2(520,515),Vector2(190,375)]
        msg = "MÀN 1: RỪNG HẮC ẢNH"
    elif Game.level == 2:
        platforms += [
            Rect2(420, 950, 210, 28), Rect2(100, 830, 210, 28),
            Rect2(390, 700, 220, 28), Rect2(90, 560, 210, 28),
            Rect2(400, 420, 230, 28), Rect2(120, 280, 220, 28)]
        enemies = [{"p":Vector2(520,1020),"hp":3},{"p":Vector2(190,770),"hp":3},{"p":Vector2(500,640),"hp":4},{"p":Vector2(180,500),"hp":4},{"p":Vector2(520,360),"hp":4}]
        coins = [Vector2(520,900),Vector2(200,780),Vector2(500,650),Vector2(190,510),Vector2(520,370),Vector2(220,230)]
        msg = "MÀN 2: THÀNH TRÌ BÓNG ĐÊM"
    else:
        platforms += [
            Rect2(100, 930, 220, 28), Rect2(400, 790, 220, 28),
            Rect2(100, 650, 220, 28), Rect2(400, 510, 220, 28),
            Rect2(100, 370, 220, 28), Rect2(390, 230, 240, 28)]
        enemies = [{"p":Vector2(520,1020),"hp":4},{"p":Vector2(190,870),"hp":4},{"p":Vector2(500,730),"hp":4},{"p":Vector2(190,590),"hp":5}]
        coins = [Vector2(190,885),Vector2(520,745),Vector2(190,605),Vector2(520,465),Vector2(190,325)]
        boss_hp = 12
        msg = "MÀN 3: ĐỐI ĐẦU MA VƯƠNG"
    msg_t = 2.5

func _physics_process(d):
    if won:
        queue_redraw()
        return

    attack_t = max(0.0, attack_t-d)
    attack_cd = max(0.0, attack_cd-d)
    invuln = max(0.0, invuln-d)
    msg_t = max(0.0, msg_t-d)

    var dir = 0.0
    if Input.is_action_pressed("move_left"): dir -= 1.0
    if Input.is_action_pressed("move_right"): dir += 1.0
    if touch_left(): dir -= 1.0
    if touch_right(): dir += 1.0

    var speed = 330.0 + Game.speed_level*35.0
    vel.x = move_toward(vel.x, dir*speed, 2200*d)
    if dir != 0: facing = sign(dir)
    vel.y += GRAVITY*d
    player += vel*d
    player.x = clamp(player.x, 35.0, W-35.0)

    var grounded = false
    for r in platforms:
        if player.x > r.position.x-24 and player.x < r.end.x+24 and player.y+54 >= r.position.y and player.y+54 <= r.position.y+45 and vel.y >= 0:
            player.y = r.position.y-54
            vel.y = 0
            grounded = true

    if (Input.is_action_just_pressed("jump") or touch_jump()) and grounded:
        vel.y = -720

    if Input.is_action_just_pressed("attack") or touch_attack():
        if attack_cd <= 0:
            attack_t = .20
            attack_cd = .28
            do_attack()

    for e in enemies:
        if e.hp <= 0: continue
        var dist = player.distance_to(e.p)
        if dist < 360:
            e.p.x += sign(player.x-e.p.x)*75*d
        if dist < 65 and invuln <= 0:
            hp -= 1
            invuln = .9
            e.p.x -= sign(player.x-e.p.x)*100
            if hp <= 0:
                Game.goto_level()
                return

    if Game.level == 3 and boss_hp > 0:
        var bd = player.distance_to(boss_pos)
        if bd < 500:
            boss_pos.x += sign(player.x-boss_pos.x)*45*d
        if bd < 90 and invuln <= 0:
            hp -= 2
            invuln = 1.0
            if hp <= 0:
                Game.goto_level()
                return

    for i in range(coins.size()-1,-1,-1):
        if player.distance_to(coins[i]) < 55:
            Game.coins += 25
            coins.remove_at(i)

    if Game.level == 3 and boss_hp <= 0:
        if player.distance_to(boss_pos) < 120:
            Game.complete_level()
            return
    elif player.y < 180:
        Game.complete_level()
        return

    if player.y > 1320:
        Game.goto_level()
        return

    queue_redraw()

func do_attack():
    var center = player + Vector2(facing*90,0)
    for e in enemies:
        if e.hp > 0 and center.distance_to(e.p) < 125:
            e.hp -= Game.attack_level
            Game.coins += 10
    if Game.level == 3 and center.distance_to(boss_pos) < 150:
        boss_hp -= Game.attack_level

func _screen_touch_in(rect: Rect2) -> bool:
    for i in range(Input.get_touchscreen_count()):
        if Input.is_touch_pressed(i) and rect.has_point(Input.get_touch_position(i)):
            return true
    return false

func _mouse_touch_in(rect: Rect2) -> bool:
    return Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT) and rect.has_point(get_viewport().get_mouse_position())

func touch_left():
    return _screen_touch_in(Rect2(25,1090,150,150)) or _mouse_touch_in(Rect2(25,1090,150,150))
func touch_right():
    return _screen_touch_in(Rect2(185,1090,150,150)) or _mouse_touch_in(Rect2(185,1090,150,150))
func touch_jump():
    return _screen_touch_in(Rect2(455,1090,110,150)) or _mouse_touch_in(Rect2(455,1090,110,150))
func touch_attack():
    return _screen_touch_in(Rect2(570,1050,135,190)) or _mouse_touch_in(Rect2(570,1050,135,190))

func _draw():
    var bg = ["#10223a","#241c3b","#351b25"][Game.level-1]
    draw_rect(Rect2(0,0,W,H),Color(bg))

    # Decorative vertical moon/lanterns.
    draw_circle(Vector2(585,125),52,Color("#f4e2a3"))
    for y in [220,470,720,970]:
        draw_circle(Vector2(70,y),22,Color("#284a64"))
        draw_circle(Vector2(650,y+35),18,Color("#59384f"))

    for r in platforms:
        draw_rect(r,Color("#60452f"))
        draw_rect(Rect2(r.position,Vector2(r.size.x,7)),Color("#789b4b"))

    for c in coins:
        draw_circle(c,16,Color("#f2c84b"))
        draw_circle(c,8,Color("#fff0a0"))

    for e in enemies:
        if e.hp > 0:
            draw_circle(e.p,28,Color("#9c3d48"))
            draw_circle(e.p+Vector2(-9,-7),5,Color("#ffe16b"))
            draw_circle(e.p+Vector2(9,-7),5,Color("#ffe16b"))
            draw_rect(Rect2(e.p+Vector2(-20,-42),Vector2(40,6)),Color("#2b1014"))
            draw_rect(Rect2(e.p+Vector2(-20,-42),Vector2(40*float(e.hp)/5.0,6)),Color("#e36b72"))

    if Game.level == 3 and boss_hp > 0:
        draw_circle(boss_pos,55,Color("#5f235f"))
        draw_circle(boss_pos+Vector2(-18,-10),8,Color("#ffdb5c"))
        draw_circle(boss_pos+Vector2(18,-10),8,Color("#ffdb5c"))
        draw_rect(Rect2(110,70,500,18),Color("#30102f"))
        draw_rect(Rect2(110,70,500*float(boss_hp)/12.0,18),Color("#dc4d75"))
        draw_string(ThemeDB.fallback_font,Vector2(0,55),"MA VƯƠNG",HORIZONTAL_ALIGNMENT_CENTER,720,22,Color.WHITE)

    # Player sprite: the selected child-inspired ninja image.
    var target_h = 210.0
    var ratio = float(ninja_tex.get_width())/float(ninja_tex.get_height())
    var target_w = target_h*ratio
    var rect = Rect2(player.x-target_w/2, player.y-target_h, target_w, target_h)
    if facing < 0:
        rect = Rect2(player.x+target_w/2, player.y-target_h, -target_w, target_h)
    draw_texture_rect(ninja_tex, rect, false)

    if attack_t > 0:
        draw_arc(player+Vector2(facing*55,-70),85,-1.0,1.0,20,Color("#e6f7ff"),10)

    draw_rect(Rect2(18,16,684,105),Color(0,0,0,.48))
    draw_string(ThemeDB.fallback_font,Vector2(35,50),"MÀN "+str(Game.level)+"   ❤️ "+str(hp)+"/"+str(Game.max_hp)+"   🪙 "+str(Game.coins),HORIZONTAL_ALIGNMENT_LEFT,-1,24,Color.WHITE)
    draw_string(ThemeDB.fallback_font,Vector2(35,84),"⚔ Lv."+str(Game.attack_level)+"   🏃 Lv."+str(Game.speed_level),HORIZONTAL_ALIGNMENT_LEFT,-1,19,Color("#f2cf70"))

    if msg_t > 0:
        draw_string(ThemeDB.fallback_font,Vector2(0,160),msg,HORIZONTAL_ALIGNMENT_CENTER,720,28,Color.WHITE)

    # Touch controls
    for x in [90,260]:
        draw_circle(Vector2(x,1165),64,Color(0,0,0,.48))
    draw_string(ThemeDB.fallback_font,Vector2(66,1180),"◀",HORIZONTAL_ALIGNMENT_LEFT,-1,42,Color.WHITE)
    draw_string(ThemeDB.fallback_font,Vector2(235,1180),"▶",HORIZONTAL_ALIGNMENT_LEFT,-1,42,Color.WHITE)
    draw_circle(Vector2(510,1165),62,Color(0,0,0,.48))
    draw_string(ThemeDB.fallback_font,Vector2(488,1180),"↑",HORIZONTAL_ALIGNMENT_LEFT,-1,42,Color.WHITE)
    draw_circle(Vector2(635,1145),72,Color(.55,.06,.08,.85))
    draw_string(ThemeDB.fallback_font,Vector2(603,1167),"⚔",HORIZONTAL_ALIGNMENT_LEFT,-1,42,Color.WHITE)
