extends Node
func _ready():
    DisplayServer.screen_set_orientation(DisplayServer.SCREEN_PORTRAIT)
    Game.goto_menu()
