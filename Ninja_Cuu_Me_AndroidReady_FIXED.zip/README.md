# Ninja Cứu Mẹ - Bé Ninja

Bản Android màn hình dọc, Godot 4.6.3.

## Build APK bằng GitHub Actions

Repository cần có toàn bộ project và file `.github/workflows/build-apk.yml`.
Workflow sẽ:
1. Cài Java 17 và Android SDK.
2. Cài Godot 4.6.3 + Android export templates đúng phiên bản.
3. Giải nén `Ninja_Cuu_Me_AndroidReady.zip`.
4. Dùng trực tiếp `export_presets.cfg` trong ZIP, không ghi đè bằng preset sai cấu hình.
5. Export APK ARM64 debug.
6. Đưa APK vào GitHub Actions Artifact.

APK này dành cho cài trực tiếp/sideload để kiểm thử. Muốn phát hành Google Play cần keystore release riêng và AAB.
