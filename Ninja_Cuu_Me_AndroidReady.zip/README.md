# Ninja Cứu Mẹ - Bé Ninja

Bản Android màn hình dọc, Godot 4.6.x.

## Có sẵn
- Nhân vật Ninja dùng hình bé đã chọn.
- Màn hình dọc 720x1280.
- 3 màn chơi.
- Quái + Boss.
- Máu, xu, nâng cấp.
- Điều khiển cảm ứng.
- Lưu tiến trình.
- Android export preset cho máy ARM64.
- Workflow GitHub Actions để build APK.

## Build APK bằng GitHub Actions

1. Upload toàn bộ project này lên repository.
2. Tạo file `.github/workflows/build-apk.yml`.
3. Copy nội dung trong `BUILD_APK_WORKFLOW.yml` vào file workflow.
4. Commit vào `main`.
5. Vào tab **Actions** → **Build Ninja Cuu Me APK**.
6. Khi chạy xong, mở workflow run → **Artifacts** → `Ninja-Cuu-Me-APK`.

Workflow dùng Godot 4.6.3 và Android SDK. APK là bản debug/sideload để cài trực tiếp trên điện thoại.
