extends Node2D
var ninja_tex = preload("res://assets/ninja_be.png")

func _ready():
    queue_redraw()

func _input(e):
    if e is InputEventKey and e.pressed and (e.keycode == KEY_ENTER or e.keycode == KEY_SPACE):
        Game.new_game()
    if e is InputEventMouseButton and e.pressed and Rect2(110,770,500,120).has_point(e.position):
        Game.new_game()

func _draw():
    draw_rect(Rect2(0,0,720,1280), Color("#07101f"))
    draw_circle(Vector2(560,150),85,Color("#f2d98c"))
    for x in [80,250,440,620]:
        draw_circle(Vector2(x,340),48,Color("#122945"))
        draw_circle(Vector2(x+42,335),58,Color("#122945"))

    var s = 300.0 / ninja_tex.get_height()
    draw_texture_rect(ninja_tex, Rect2(285,300, ninja_tex.get_width()*s,300), false)

    draw_string(ThemeDB.fallback_font,Vector2(0,90),"NINJA CỨU MẸ",HORIZONTAL_ALIGNMENT_CENTER,720,52,Color("#f5d76e"))
    draw_string(ThemeDB.fallback_font,Vector2(55,675),"BÉ NINJA - HÀNH TRÌNH GIẢI CỨU MẸ",HORIZONTAL_ALIGNMENT_CENTER,610,25,Color("#d9e7ff"))

    draw_rect(Rect2(110,770,500,120),Color("#b32636"))
    draw_string(ThemeDB.fallback_font,Vector2(0,848),"CHƠI GAME",HORIZONTAL_ALIGNMENT_CENTER,720,38,Color.WHITE)

    draw_string(ThemeDB.fallback_font,Vector2(0,970),"Màn hình dọc • Điều khiển cảm ứng",HORIZONTAL_ALIGNMENT_CENTER,720,24,Color("#a8bad4"))
    draw_string(ThemeDB.fallback_font,Vector2(0,1015),"◀ ▶  di chuyển     ↑  nhảy     ⚔  tấn công",HORIZONTAL_ALIGNMENT_CENTER,720,22,Color("#8fa8c9"))
    draw_string(ThemeDB.fallback_font,Vector2(0,1190),"Bản V2 • Nhân vật dựa trên ảnh bé đã chọn",HORIZONTAL_ALIGNMENT_CENTER,720,18,Color("#60799b"))
