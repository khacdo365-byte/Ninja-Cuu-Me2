extends Node2D
var ninja_tex = preload("res://assets/ninja_be.png")

func _ready(): queue_redraw()

func _input(e):
    if e is InputEventMouseButton and e.pressed: Game.goto_menu()
    if e is InputEventKey and e.pressed and e.keycode == KEY_ENTER: Game.goto_menu()

func _draw():
    draw_rect(Rect2(0,0,720,1280),Color("#081326"))
    draw_circle(Vector2(360,390),120,Color("#f0b49f"))
    var s = 260.0 / ninja_tex.get_height()
    draw_texture_rect(ninja_tex,Rect2(230,250,ninja_tex.get_width()*s,260),false)
    draw_string(ThemeDB.fallback_font,Vector2(0,115),"MẸ ĐÃ ĐƯỢC CỨU!",HORIZONTAL_ALIGNMENT_CENTER,720,48,Color("#f5d76e"))
    draw_string(ThemeDB.fallback_font,Vector2(60,760),"Bé Ninja đã vượt qua 3 màn!",HORIZONTAL_ALIGNMENT_CENTER,600,28,Color.WHITE)
    draw_string(ThemeDB.fallback_font,Vector2(0,1040),"Chạm màn hình để chơi lại",HORIZONTAL_ALIGNMENT_CENTER,720,24,Color("#a8bad4"))
